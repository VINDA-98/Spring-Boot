create
    definer = root@`%` procedure pro_week()
begin
	declare w int default 0; -- 用来获取新周
    select max(week) + 1 into w from weekinfo;
    
	insert into weekinfo(id,week,limits) 
	select id,w, 
    (select concat(date_format(curdate(),'%Y年%m月%d日'),'-',date_format(curdate(),'%m月%d日'),
		'(第',(select max(week)+1 from weekinfo),'周)')) 
        from user where id != 20200001;
end;

